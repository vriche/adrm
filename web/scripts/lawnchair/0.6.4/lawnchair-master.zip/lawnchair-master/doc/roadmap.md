Roadmap
===

0.7.x
---

- multiple collections
- blackberry adapter
- gears adapter
- ie adapter
- window-name adapter

0.8.x
---

- ability to name adapter as a cache (for in memory ops or to fallback to server store)
- decorator plugin for augmenting normal objects with persistence

0.9.x
---

- package.json
- redis, couch, riak adapters


Future Plugin Ideas...
---

    money ........ js is notoriously uncool w/ money types; this could useful
    logging ...... keep a log of all operations
    versioning ... another form paranoia
    text-seach ... full text search
    timestamp .... adds modified and created fields to every collection record
    validation ... validate collection data with json schema
    encryption ... encrypt local data (just don't keep the key on the client, eh).
    iteration .... extended iterator methods


